/*Driver App Configuration*/

var krms_driver_config ={			
	'ApiUrl':"http://ojeelojee.com/driver/api",		
	'DialogDefaultTitle':"Delivery Boy App",
	'mapboxToken' : '',
	'APIHasKey':"oMSjuDBkAShdssfksnd",
	'debug': false
};